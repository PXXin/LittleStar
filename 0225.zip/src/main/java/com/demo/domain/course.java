package com.demo.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

@TableName("course")
public class course {
    @TableId(value = "cuuid",type = IdType.AUTO)
    private Integer cuuid;
    @TableField("cId")
    private Integer cId;
    @TableField("cName")
    private String cName;
    @TableField("cImageLink")
    private String cImageLink;
    @TableField("cMajor")
    private String cMajor;
    @TableField("cGrade")
    private String cGrade;
    @TableField("teacherId")
    private Integer teacherId;
    @TableField("cSemester")
    private String cSemester;
    @TableField("cInfo")
    private String cInfo;

    public course(Integer cuuid, Integer cId, String cName, String cImageLink, String cMajor, String cGrade, Integer teacherId, String cSemester, String cInfo) {
        this.cuuid = cuuid;
        this.cId = cId;
        this.cName = cName;
        this.cImageLink = cImageLink;
        this.cMajor = cMajor;
        this.cGrade = cGrade;
        this.teacherId = teacherId;
        this.cSemester = cSemester;
        this.cInfo = cInfo;
    }

    public course() {
    }

    public Integer getCuuid() {
        return cuuid;
    }

    public void setCuuid(Integer cuuid) {
        this.cuuid = cuuid;
    }

    public Integer getcId() {
        return cId;
    }

    public void setcId(Integer cId) {
        this.cId = cId;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }

    public String getcImageLink() {
        return cImageLink;
    }

    public void setcImageLink(String cImageLink) {
        this.cImageLink = cImageLink;
    }

    public String getcMajor() {
        return cMajor;
    }

    public void setcMajor(String cMajor) {
        this.cMajor = cMajor;
    }

    public String getcGrade() {
        return cGrade;
    }

    public void setcGrade(String cGrade) {
        this.cGrade = cGrade;
    }

    public Integer getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(Integer teacherId) {
        this.teacherId = teacherId;
    }

    public String getcSemester() {
        return cSemester;
    }

    public void setcSemester(String cSemester) {
        this.cSemester = cSemester;
    }

    public String getcInfo() {
        return cInfo;
    }

    public void setcInfo(String cInfo) {
        this.cInfo = cInfo;
    }
}
