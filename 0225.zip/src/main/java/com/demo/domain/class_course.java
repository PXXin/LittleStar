package com.demo.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

@TableName("class_course")
public class class_course {
    @TableId(value = "uuid",type = IdType.AUTO)
    private Integer uuid;
    @TableField("cId")
    private Integer cId;
    @TableField("classId")
    private Integer classId;
    @TableField("semester")
    private String semester;
    @TableField("major")
    private String major;

    @Override
    public String toString() {
        return "class_course{" +
                "uuid=" + uuid +
                ", cId=" + cId +
                ", classId=" + classId +
                ", semester='" + semester + '\'' +
                ", major='" + major + '\'' +
                '}';
    }

    public Integer getUuid() {
        return uuid;
    }

    public void setUuid(Integer uuid) {
        this.uuid = uuid;
    }

    public Integer getcId() {
        return cId;
    }

    public void setcId(Integer cId) {
        this.cId = cId;
    }

    public Integer getClassId() {
        return classId;
    }

    public void setClassId(Integer classId) {
        this.classId = classId;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

}
