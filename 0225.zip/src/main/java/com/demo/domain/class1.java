package com.demo.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

@TableName("class")
public class class1 {
    @TableId(value = "uuid",type = IdType.AUTO)
    private Integer uuid;
    @TableField("classId")
    private Integer classId;
    @TableField("className")
    private String className;
    @TableField("classStuNum")
    private Integer classStuNum;
    @TableField("classGrade")
    private String classGrade;
    @TableField("classMajor")
    private String classMajor;

    @Override
    public String toString() {
        return "class1{" +
                "uuid=" + uuid +
                ", classId=" + classId +
                ", className='" + className + '\'' +
                ", classStuNum=" + classStuNum +
                ", classGrade='" + classGrade + '\'' +
                ", classMajor='" + classMajor + '\'' +
                '}';
    }

    public Integer getUuid() {
        return uuid;
    }

    public void setUuid(Integer uuid) {
        this.uuid = uuid;
    }

    public Integer getClassId() {
        return classId;
    }

    public void setClassId(Integer classId) {
        this.classId = classId;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public Integer getClassStuNum() {
        return classStuNum;
    }

    public void setClassStuNum(Integer classStuNum) {
        this.classStuNum = classStuNum;
    }

    public String getClassGrade() {
        return classGrade;
    }

    public void setClassGrade(String classGrade) {
        this.classGrade = classGrade;
    }

    public String getClassMajor() {
        return classMajor;
    }

    public void setClassMajor(String classMajor) {
        this.classMajor = classMajor;
    }
}
