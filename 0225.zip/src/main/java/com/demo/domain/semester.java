package com.demo.domain;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
@TableName("semester")
public class semester {
    @TableId(value = "uuid",type = IdType.AUTO)
    private Integer uuid;
    @TableField("semester")
    private String semester;

    @Override
    public String toString() {
        return "semester{" +
                "uuid=" + uuid +
                ", current_semester='" + semester + '\'' +
                '}';
    }

    public Integer getUuid() {
        return uuid;
    }

    public void setUuid(Integer uuid) {
        this.uuid = uuid;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }
}
