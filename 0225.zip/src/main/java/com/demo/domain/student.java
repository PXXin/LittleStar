package com.demo.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;

@TableName("student")
public class student {
    @TableId(value = "uuid",type = IdType.AUTO)
    private Integer uuid;
    @TableField("stuId")
    private String stuId;
    @TableField("stuPwd")
    private String stuPwd;
    @TableField("stuName")
    private String stuName;
    @TableField("stuMajor")
    private String stuMajor;
    @TableField("stuGrade")
    private String stuGrade;
    @TableField("stuClassId")
    private String stuClassId;
    @TableField("stuMail")
    private String stuMail;


    @Override
    public String toString() {
        return "student{" +
                "uuid=" + uuid +
                ", stuId='" + stuId + '\'' +
                ", stuPwd='" + stuPwd + '\'' +
                ", stuName='" + stuName + '\'' +
                ", stuMajor='" + stuMajor + '\'' +
                ", stuGrade='" + stuGrade + '\'' +
                ", stuClassId='" + stuClassId + '\'' +
                ", stuMail='" + stuMail + '\'' +
                '}';
    }

    public Integer getUuid() {
        return uuid;
    }

    public void setUuid(Integer uuid) {
        this.uuid = uuid;
    }

    public String getStuId() {
        return stuId;
    }

    public void setStuId(String stuId) {
        this.stuId = stuId;
    }

    public String getStuPwd() {
        return stuPwd;
    }

    public void setStuPwd(String stuPwd) {
        this.stuPwd = stuPwd;
    }

    public String getStuName() {
        return stuName;
    }

    public void setStuName(String stuName) {
        this.stuName = stuName;
    }

    public String getStuMajor() {
        return stuMajor;
    }

    public void setStuMajor(String stuMajor) {
        this.stuMajor = stuMajor;
    }

    public String getStuGrade() {
        return stuGrade;
    }

    public void setStuGrade(String stuGrade) {
        this.stuGrade = stuGrade;
    }

    public String getStuClassId() {
        return stuClassId;
    }

    public void setStuClassId(String stuClassId) {
        this.stuClassId = stuClassId;
    }

    public String getStuMail() {
        return stuMail;
    }

    public void setStuMail(String stuMail) {
        this.stuMail = stuMail;
    }



}
