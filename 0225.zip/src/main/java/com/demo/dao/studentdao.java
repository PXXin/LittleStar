package com.demo.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.demo.domain.student;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;


@Mapper
@Service
public interface studentdao extends BaseMapper<student> {



    @Select({"select * from student where uuid = #{uuid}"})
    public student selectByuuid(@Param("uuid") int uuid);

    @Delete({"delete from student where uuid = #{uuid}"})
    public int deleteByuuid(@Param("uuid") int uuid);
    @Select({"SELECT DISTINCT  stuGrade FROM student "})
    public List<String> SDstuGrade();
    @Select({"SELECT DISTINCT  stuClassId FROM student where stuGrade=#{stuGrade}"})
    public List<String> SDstuClassIdG(@Param("stuGrade")String stuGrade);
    @Select({"SELECT DISTINCT  stuClassId FROM student where stuMajor=#{stuMajor}"})
    public List<String> SDstuClassIdM(@Param("stuMajor")String stuMjor);
    @Select({"SELECT DISTINCT  stuClassId FROM student where stuGrade=#{stuGrade} AND stuMajor=#{stuMajor}"})
    public List<String> SDstuClassIdTwoPara(@Param("stuGrade")String stuGrade,@Param("stuMajor")String stuMajor);
    @Select({"SELECT DISTINCT  stuMajor FROM student "})
    public List<String> SDstuMajor();


    //更新班级用
    @Select("SELECT DISTINCT stuClassId,stuGrade,stuMajor FROM student")
    public List<student> getDistinctClassBoxInstudent();

    //在用中
    @Select("SELECT count(*) FROM student where stuClassId=#{student.stuClassId} and stuGrade=#{student.stuGrade} and stuMajor=#{student.stuMajor}")
    Integer countNumByStu(@Param("student") student student);


    //没用
    @Select("SELECT count(*) FROM student where stuClassId=#{stuClassId} and stuGrade=#{stuGrade} and stuMajor=#{stuMajor}")
    Integer countNum(@Param("stuClassId") String stuClassId,@Param("stuGrade") String stuGrade,@Param("stuMajor") String stuMajor);
}
