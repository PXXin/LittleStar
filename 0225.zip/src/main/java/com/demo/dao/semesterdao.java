package com.demo.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.demo.domain.semester;
import com.demo.domain.student;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Service;

@Mapper
@Service
public interface semesterdao extends BaseMapper<semester> {
    @Select({"select * from semester where uuid = #{uuid}"})
    public semester selectByuuid(@Param("uuid") int uuid);

}
