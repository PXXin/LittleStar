package com.demo.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.demo.domain.class1;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Service;

import java.util.List;

@Mapper
@Service
public interface classdao extends BaseMapper<class1> {


    @Select({"SELECT DISTINCT classGrade FROM class "})
    public List<String> SDGrade();
    @Select({"SELECT DISTINCT classMajor FROM class "})
    public List<String> SDMajor();

    //更新用
    @Update("UPDATE class SET classStuNum = #{num} where classId=#{classId} and classGrade=#{classGrade} and classMajor=#{classMajor}")
    boolean updateByStu(@Param("classId") String classId,@Param("classGrade") String classGrade,@Param("classMajor") String classMajor, @Param("num")int num);

    //判断是否存在该班级，若不存在，则自动新增
    @Select({"SELECT count(ClassId) FROM class where ClassId=#{ClassId} and classGrade=#{classGrade} AND classMajor=#{classMajor}"})
    public int SDstuClassIdthreePara(@Param("ClassId")String ClassId,@Param("classGrade")String classGrade,@Param("classMajor")String classMajor);

    @Select({"SELECT classId FROM class where classGrade=#{classGrade}  AND classMajor=#{classMajor}"})
    List<Integer> selectByGM(@Param("classGrade") String grade, @Param("classMajor") String major);

    @Select({"SELECT DISTINCT classGrade FROM class where classMajor=#{major}"})
    List<String> SDGradeBycc(@Param("major")String major);
//    @Select({"SELECT count(stuClassId) FROM class where stuClassId=#{stuClassId} and stuGrade=#{stuGrade} AND stuMajor=#{stuMajor}"})
//    public int SDstuClassIdTwoPara(@Param("stuGrade")String stuGrade,@Param("stuMajor")String stuMajor);
}
