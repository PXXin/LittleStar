package com.demo.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.demo.domain.teachers;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Service;

@Mapper
@Service
public interface teachersdao extends BaseMapper<teachers> {
    @Update({"UPDATE teachers SET flag ='false' where teacherId = #{teacherId}"})
    public boolean deleteByTeacherId(@Param("teacherId")int teacherId);
    @Delete({"delete from teachers where uuid = #{uuid}"})
    public  int deleteByuuid(@Param("uuid")int uuid);

}
