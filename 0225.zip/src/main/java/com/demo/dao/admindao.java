package com.demo.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.demo.domain.admin;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Service;

@Mapper
@Service
public interface admindao extends BaseMapper<admin> {
    @Select("select adminPwd from admin where  adminId=#{account} ")
    public String  confirm(@Param("account")String account);


}
