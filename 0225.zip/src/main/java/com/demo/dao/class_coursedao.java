package com.demo.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.demo.domain.class_course;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Service;

import java.util.List;

@Mapper
@Service
public interface class_coursedao extends BaseMapper<class_course> {

    @Delete({"delete from class_course where uuid = #{uuid}"})
    Boolean deleteByUuId(@Param("uuid") Integer uuId);

    @Select({"SELECT DISTINCT major FROM class_course"})
    List<String> SDMajor();

    @Select({"SELECT DISTINCT semester FROM class_course where major=#{major}"})
    List<String> SDSemester(@Param("major") String major);


}
