package com.demo.service;

import com.demo.domain.semester;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;


import org.springframework.stereotype.Service;




public interface semesterService extends IService<semester>{
    semester getSemester(int uuid);
    boolean updateSemester(semester semester);

}
