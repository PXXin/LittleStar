package com.demo.service;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.demo.domain.student;

import org.springframework.stereotype.Service;

import java.util.List;



@Service
public interface studentService extends IService<student> {
    student selectByUuid(int uuid);
    boolean save(student student);
    boolean update(student student);
    boolean deleteByuuId(int uuid);
    List<String> SDstuMajor();
    List<String> SDstuClassId(String stuGrade,String stuMajor);
    List<String> SDstuGrade();
    IPage findallbypage(IPage page, LambdaQueryWrapper<student> LambdaQueryWrapper);
    IPage<student> getPage(int currentPage, int pageSize, student student);

    //更新班级
    List<student> getDistinctClass();
   // Integer countNum(String stuClassId,String stuGrade,String stuMajor);
    Integer countNumByStu(student student);
}
