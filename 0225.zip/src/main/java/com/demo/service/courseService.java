package com.demo.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.demo.domain.class1;
import com.demo.domain.course;
import org.springframework.stereotype.Service;

@Service
public interface courseService extends IService<course> {
    IPage<course> getPage(int currentPage, int pageSize, course course);

    boolean updateBycuuid(course course);
}
