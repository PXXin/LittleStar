package com.demo.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.demo.domain.class1;
import com.demo.domain.student;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface classService extends IService<class1> {

    IPage<class1> getPage(int currentPage, int pageSize, class1 cls);
    boolean save(class1 c);
    boolean update(class1 c);
    boolean deleteById(String classId);
    List<String> SDMajor();
    List<String> SDGrade();

    //更新班级用
    boolean updateByStu(String classId ,String classGrade ,String classMajor,int num);

}
