package com.demo.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.demo.domain.teachers;
import org.springframework.stereotype.Service;

@Service
public interface teachersService extends IService<teachers> {

    boolean saveBook(teachers teachers);

    boolean modify(teachers teachers);

    boolean delete(Integer id);

    IPage<teachers> getPage(int currentPage, int pageSize, teachers teachers);
}
