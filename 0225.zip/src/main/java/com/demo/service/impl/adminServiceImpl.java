package com.demo.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.demo.dao.admindao;

import com.demo.domain.admin;

import com.demo.service.adminService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class adminServiceImpl extends ServiceImpl<admindao, admin> implements adminService {
    @Resource
    private admindao admindao;
    @Override
    public boolean confirm(String account, String password) {
        String a=admindao.confirm(account);
        if(a!=null)
        return password.compareTo(a)>0;
        else
            return false;
    }
}
