package com.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.demo.dao.teachersdao;
import com.demo.domain.teachers;
import com.demo.service.teachersService;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class teachersServiceImpl extends ServiceImpl<teachersdao, teachers> implements teachersService {


    @Autowired
    private teachersdao teachersdao;

    @Override
    public boolean saveBook(teachers teachers) {
        return teachersdao.insert(teachers) > 0;
    }

    @Override
    public boolean modify(teachers teachers) {
        return teachersdao.updateById(teachers) > 0;
    }

    @Override
    public boolean delete(Integer id) {
        return teachersdao.deleteByuuid(id) >0;
    }



    @Override
    public IPage<teachers> getPage(int currentPage, int pageSize, teachers teachers) {
        LambdaQueryWrapper<teachers> lqw = new LambdaQueryWrapper<teachers>();
        lqw.like(Strings.isNotEmpty(teachers.getTeacherName()), com.demo.domain.teachers::getTeacherName,teachers.getTeacherName());
        lqw.like(Strings.isNotEmpty(teachers.getFlag()), com.demo.domain.teachers::getFlag,teachers.getFlag());
        IPage page = new Page(currentPage,pageSize);
        teachersdao.selectPage(page,lqw);
        return page;
    }
}
