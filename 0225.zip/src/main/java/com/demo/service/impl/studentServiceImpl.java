package com.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.demo.dao.studentdao;
import com.demo.domain.student;
import com.demo.service.studentService;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class studentServiceImpl extends ServiceImpl<studentdao,student> implements studentService {
    @Resource
    private studentdao studentdao;

    @Override
    public student selectByUuid(int uuid) {
        return studentdao.selectByuuid(uuid);
    }

    @Override
    public boolean save(student student) {
        return studentdao.insert(student)>0;
    }

    @Override
    public boolean update(student student) {
        return studentdao.updateById(student)>0;
    }

    @Override
    public boolean deleteByuuId(int uuid) {
        return studentdao.deleteByuuid(uuid)>0;
    }

    @Override
    public List<String> SDstuMajor() {
       List< String> strings=studentdao.SDstuMajor();
      //  System.out.println(strings);
        return strings;
    }

    @Override
    public List<String> SDstuClassId(String stuGrade,String stuMajor) {
        if(Strings.isEmpty(stuGrade))
            return studentdao.SDstuClassIdM(stuMajor);
        else if(Strings.isEmpty(stuMajor))
            return studentdao.SDstuClassIdG(stuGrade);
        return studentdao.SDstuClassIdTwoPara(stuGrade, stuMajor);

    }

    @Override
    public List<String> SDstuGrade() {
        return studentdao.SDstuGrade();
    }

    @Override
    public IPage findallbypage(IPage page, LambdaQueryWrapper<student> LambdaQueryWrapper) {
        return studentdao.selectPage(page,LambdaQueryWrapper);
    }

    @Override
    public IPage<student> getPage(int currentPage, int pageSize, student student) {
        LambdaQueryWrapper<student> lqw = new LambdaQueryWrapper<student>();
        lqw.like(Strings.isNotEmpty(student.getStuName()), com.demo.domain.student::getStuName,student.getStuName());
        lqw.like(Strings.isNotEmpty(student.getStuClassId()), com.demo.domain.student::getStuClassId,student.getStuClassId());
        lqw.like(Strings.isNotEmpty(student.getStuGrade()), com.demo.domain.student::getStuGrade,student.getStuGrade());
        lqw.like(Strings.isNotEmpty(student.getStuId()), com.demo.domain.student::getStuId,student.getStuId());
        lqw.like(Strings.isNotEmpty(student.getStuMajor()), com.demo.domain.student::getStuMajor,student.getStuMajor());
        IPage iPage = new Page(currentPage,pageSize);
        studentdao.selectPage(iPage,lqw);
        return iPage;
    }

    //更新班级用
    @Override
    public List<student> getDistinctClass() {
        return studentdao.getDistinctClassBoxInstudent();
    }

    @Override
    public Integer countNumByStu(student student) {
        return studentdao.countNumByStu(student);
    }


    /*
    * @Override
    public IPage<teachers> getPage(int currentPage, int pageSize, teachers teachers) {
        LambdaQueryWrapper<teachers> lqw = new LambdaQueryWrapper<teachers>();
       //lqw.like(teachers.getUuid()!=0, com.demo.domain.teachers::getUuid,teachers.getUuid());
        lqw.like(Strings.isNotEmpty(teachers.getTeacherName()), com.demo.domain.teachers::getTeacherName,teachers.getTeacherName());
        lqw.like(Strings.isNotEmpty(teachers.getFlag()), com.demo.domain.teachers::getFlag,teachers.getFlag());
        IPage page = new Page(currentPage,pageSize);
        teachersdao.selectPage(page,lqw);
        return page;
    }*/
}
