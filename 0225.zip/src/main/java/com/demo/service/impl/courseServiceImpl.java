package com.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.demo.dao.coursedao;
import com.demo.dao.studentdao;
import com.demo.domain.class1;
import com.demo.domain.course;
import com.demo.service.courseService;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class courseServiceImpl extends ServiceImpl<coursedao, course> implements courseService {
    @Resource
    private com.demo.dao.coursedao coursedao;
    @Override
    public IPage<course> getPage(int currentPage, int pageSize, course cs) {
        LambdaQueryWrapper<course> lqw = new LambdaQueryWrapper<course>();
        //lqw.like(Strings.isNotEmpty(cs.getcId().toString()),course::getcId,cs.getcId());
       // lqw.like(Strings.isNotEmpty(cs.getcName()),course::getcName,cs.getcName());
        //lqw.like(Strings.isNotEmpty(cs.getcMajor()),course::getcMajor,cs.getcMajor());
       // lqw.like(Strings.isNotEmpty(cs.getcGrade()),course::getcGrade,cs.getcGrade());
       // lqw.like(Strings.isNotEmpty(cs.getTeacherId().toString()),course::getTeacherId,cs.getTeacherId());
        //lqw.like(Strings.isNotEmpty(cs.getcSemester()),course::getcSemester,cs.getcSemester());
       // lqw.like(Strings.isNotEmpty(cs.getcInfo()),course::getcInfo,cs.getcInfo());
        IPage iPage = new Page(currentPage,pageSize);
        coursedao.selectPage(iPage,lqw);
        return iPage;
    }

    @Override
    public boolean updateBycuuid(course course) {
        return coursedao.updateById(course)>0;
    }

}
