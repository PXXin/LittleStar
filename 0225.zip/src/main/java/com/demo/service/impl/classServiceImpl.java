package com.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.demo.dao.classdao;
import com.demo.domain.class1;
import com.demo.domain.student;
import com.demo.service.classService;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class classServiceImpl extends ServiceImpl<classdao, class1> implements classService {
    @Autowired
    private classdao classdao;
    @Override
    public boolean save(class1 c) {
        return classdao.insert(c)>0;
    }

    @Override
    public boolean update(class1 c) {
        return classdao.updateById(c)>0;
    }

    @Override
    public boolean deleteById(String Id) {
        return classdao.deleteById(Id)>0;
    }

    @Override
    public List<String> SDMajor() {
        List< String> strings=classdao.SDMajor();
        //  System.out.println(strings);
        return strings;
    }



    @Override
    public List<String> SDGrade() {
        return classdao.SDGrade();
    }

    @Override
    public IPage<class1> getPage(int currentPage, int pageSize, class1 cls) {
        LambdaQueryWrapper<class1> lqw = new LambdaQueryWrapper<class1>();

        lqw.like(Strings.isNotEmpty(cls.getClassGrade()),class1::getClassGrade,cls.getClassGrade());
        lqw.like(Strings.isNotEmpty(cls.getClassMajor()),class1::getClassMajor,cls.getClassMajor());
        IPage iPage = new Page(currentPage,pageSize);
        classdao.selectPage(iPage,lqw);
        return iPage;
    }

    //更新用
    @Override
    public boolean updateByStu(String classId,String classGrade,String classMajor,int num) {
        if(classdao.SDstuClassIdthreePara(classId,classGrade,classMajor)==0){
            class1 cc=new class1();
            cc.setClassId(Integer.parseInt(classId));
            cc.setClassName(classId);
            cc.setClassGrade(classGrade);
            cc.setClassMajor(classMajor);
            System.out.println(cc);
            classdao.insert(cc);
        }

        return classdao.updateByStu(classId,classGrade,classMajor,num);
    }

}
