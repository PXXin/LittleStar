package com.demo.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.demo.dao.semesterdao;
import com.demo.domain.semester;
import com.demo.service.semesterService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class semesterServiceImpl extends ServiceImpl<semesterdao,semester>implements semesterService {
    @Resource
    private semesterdao semesterdao;

    @Override
    public semester getSemester(int uuid) {
        return semesterdao.selectByuuid(uuid);
    }

    @Override
    public boolean updateSemester(semester semester) {
        return semesterdao.updateById(semester)>0;
    }
}
