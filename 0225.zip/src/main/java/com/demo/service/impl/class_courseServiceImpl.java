package com.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.demo.dao.class_coursedao;
import com.demo.dao.classdao;
import com.demo.domain.class1;
import com.demo.domain.class_course;
import com.demo.service.class_courseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class class_courseServiceImpl extends ServiceImpl<class_coursedao, class_course> implements class_courseService {
    @Autowired
    private class_coursedao class_coursedao;
    @Autowired
    private classdao classdao;
    @Override
    public IPage findallbypage(IPage page, LambdaQueryWrapper<class_course> LambdaQueryWrapper) {
        return class_coursedao.selectPage(page,LambdaQueryWrapper);

    }

    @Override
    public IPage<class_course> getPage(int currentPage, int pageSize, class_course cc) {

        IPage<class_course> ipage = new Page<class_course>(currentPage, pageSize);
        LambdaQueryWrapper<class_course> lqw = new LambdaQueryWrapper<class_course>();
        lqw.like(cc.getcId() != null, class_course::getcId, cc.getcId());
        lqw.like(cc.getClassId() != null, class_course::getClassId, cc.getClassId());
        lqw.like(cc.getSemester() != null, class_course::getSemester, cc.getSemester());
        lqw.like(cc.getMajor() != null, class_course::getMajor, cc.getMajor());
        return class_coursedao.selectPage(ipage, lqw);
    }

    @Override
    public Boolean deleteByUuID(Integer uuId) {
        return class_coursedao.deleteByUuId(uuId);
    }

    @Override
    public List<String> SDMajor() {
        return class_coursedao.SDMajor();
    }

    @Override
    public List<String> SDSemester(String major) {
        return class_coursedao.SDSemester(major);
    }
    @Override
    public int saveByGrade(String grade,Integer cId,String semester,String major){
        class1 class1 = new class1();
        class1.setClassMajor(major);
        class1.setClassGrade(grade);
        List<Integer> stringList = classdao.selectByGM(grade, major);
        int res = 0;
        for (Integer s : stringList) {
            class_course cc = new class_course();
            cc.setMajor(major);
            cc.setcId(cId);
            cc.setSemester(semester);
            cc.setClassId(s);
            int insert = class_coursedao.insert(cc);
            res+=insert;
        }
        return res;
    }

    @Override
    public List<String> SDGrade(String major) {
        return classdao.SDGradeBycc(major);
    }

}
