package com.demo.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.demo.domain.class1;
import com.demo.domain.class_course;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface class_courseService extends IService<class_course> {

    IPage findallbypage(IPage page, LambdaQueryWrapper<class_course> LambdaQueryWrapper);

    IPage<class_course> getPage(int currentPage, int pageSize, class_course cc);

    Boolean deleteByUuID (Integer uuId );

    List<String> SDMajor();

    List<String> SDSemester(String major);

    int saveByGrade(String grade,Integer cId,String semester,String major);

    List<String> SDGrade(String major);
}
