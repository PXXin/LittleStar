package com.demo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.demo.domain.admin;

public interface adminService extends IService<admin> {
    public boolean confirm(String account,String password);
}
