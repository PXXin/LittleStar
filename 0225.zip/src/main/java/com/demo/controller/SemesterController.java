package com.demo.controller;

import com.demo.domain.semester;

import com.demo.service.semesterService;
import com.demo.utils.R;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@RestController
@RequestMapping("/semester")
public class SemesterController {
    private final semesterService semesterService;

    public SemesterController( semesterService serviceService) {
       this.semesterService=serviceService;
    }
    @GetMapping("{id}")
    public R getById(@PathVariable Integer id){
        return new R(true, semesterService.getById(id));
    }


    @PutMapping
    public R update( semester semester)  {
        boolean flag = semesterService.updateSemester(semester);
        return new R(flag, flag ? "修改成功^_^" : "修改失败-_-!");
    }

}
