package com.demo.controller;


import com.demo.dao.admindao;
import com.demo.service.adminService;

import com.demo.utils.R;
import org.springframework.aop.scope.ScopedProxyUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;


@RestController
@RequestMapping("/admin")
public class AdminController {
    private final adminService adminService;
    @Resource
    private com.demo.dao.admindao admindao;

    public AdminController( adminService adminService) {
        this.adminService=adminService;
    }

    @RequestMapping("{account}")
    public R confirm(@PathVariable String account, @RequestBody String password){


    return new R(adminService.confirm(account, password));
}
}
