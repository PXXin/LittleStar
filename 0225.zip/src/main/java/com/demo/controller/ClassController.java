package com.demo.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.demo.domain.class1;
import com.demo.service.classService;
import com.demo.service.studentService;
import com.demo.utils.R;
import org.apache.ibatis.annotations.Delete;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("Class")
public class ClassController {
    private final com.demo.service.classService classService;
    private final com.demo.service.studentService studentService;


    public ClassController(classService classService, com.demo.service.studentService studentService) {
        this.classService = classService;
        this.studentService=studentService;
    }


    @PostMapping
    public R save(@RequestBody class1 cls){
        boolean flag = false;
        flag = classService.save(cls);
        if(flag){

        }
        return new R(flag, flag? "添加成功^_^" : "添加失败-_-!");
    }
    @GetMapping("SDMajor")
    public R getSDMajor(){
        return new R(true, classService.SDMajor());
    }
    @GetMapping("SDGrade")
    public R getSDGrade(){
        return new R(true, classService.SDGrade());
    }
//    @PutMapping
//    public R update(@RequestBody class1 cls){
//        boolean b = classService.updateById(cls);
//        return new R (b,b?"修改成功^_^" : "修改失败-_-!");
//    }

    @DeleteMapping(("{id}"))
    public R delete(@PathVariable String id){
        return new R(classService.deleteById(id));
    }


//    @GetMapping("{id}")
//    public R gerById(@PathVariable String id){
//
//        //uuid
//        class1 byId = classService.getById(id);
//
//        return new R(byId!=null,byId);
//    }

    @GetMapping("{currentPage}/{pageSize}")
    public R getPage(@PathVariable int currentPage , @PathVariable int pageSize ,class1 cls){
        IPage<class1> page = classService.getPage(currentPage, pageSize, cls);
        if(currentPage>page.getPages())
            page=classService.getPage((int)page.getPages(), pageSize,cls);
        return new R(true,page);
    }

}
