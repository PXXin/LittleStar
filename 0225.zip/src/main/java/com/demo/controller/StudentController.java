package com.demo.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.demo.domain.student;

import com.demo.service.classService;
import com.demo.service.studentService;
import com.demo.utils.R;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/Student")
public class StudentController {

    private final studentService studentService;
    private final classService classService;

    public StudentController(classService classService, com.demo.service.studentService studentService) {
        this.classService = classService;
        this.studentService=studentService;
    }

    @GetMapping("updateClassTables")
    public R refresh(){
        List<student> students=studentService.getDistinctClass();

        students.forEach(origin->{
            classService.updateByStu(origin.getStuClassId(), origin.getStuGrade(),
                    origin.getStuMajor(), studentService.countNumByStu(origin));
        });
        return  new R(true);
    }

    @GetMapping
    public R getAll(){
        System.out.println("getall being call&&&&&&&&&&&&&&&&&&&&&&&&&");
        return new R(true, studentService.list());
    }
    @GetMapping("SDMajor")
    public R getSDMajor(){
        return new R(true, studentService.SDstuMajor());
    }
    @GetMapping("SDGrade")
    public R getSDGrade(){
        return new R(true, studentService.SDstuGrade());
    }
    @GetMapping("SDClassId")
    public R getSDClassId( String stuGrade, String stuMajor){
       // System.out.println("stugrade_______________________"+stuGrade);
        return new R(true, studentService.SDstuClassId(stuGrade,stuMajor));
    }

    @DeleteMapping("{uuid}")
    public R delete(@PathVariable int uuid){
        student origin=studentService.getById(uuid);
        boolean flag=studentService.deleteByuuId(uuid);
        if(flag) {

            classService.updateByStu(origin.getStuClassId(), origin.getStuGrade(),
                    origin.getStuMajor(), studentService.countNumByStu(origin));
        }

        return new R(flag);
    }
    @GetMapping("{id}")
    public R getById(@PathVariable Integer id){
        return new R(true, studentService.getById(id));
    }

    @PostMapping
    public R save(@RequestBody student student)  {


        boolean flag = studentService.save(student);
        if(flag){
            //classService.
            classService.updateByStu(student.getStuClassId(),student.getStuGrade(),student.getStuMajor(),studentService.countNumByStu(student));
        }
        return new R(flag, flag ? "添加成功^_^" : "添加失败-_-!");
    }

    @PutMapping
    public R update(@RequestBody student student) throws IOException {
        System.out.println("update being call");
        student origin=studentService.selectByUuid(student.getUuid());
        System.out.println(origin+"this origin*******************"+student.getStuId());
        boolean flag = studentService.update(student);
        if(flag) {
            classService.updateByStu(student.getStuClassId(), student.getStuGrade(),
                    student.getStuMajor(), studentService.countNumByStu(student));
            classService.updateByStu(origin.getStuClassId(), origin.getStuGrade(),
                    origin.getStuMajor(), studentService.countNumByStu(origin));
        }
        return new R(flag, flag ? "修改成功^_^" : "修改失败-_-!");
    }

    @GetMapping("{currentPage}/{pageSize}")
    public R getPage(@PathVariable int currentPage,@PathVariable int pageSize,student student){

        IPage<student> page = studentService.getPage(currentPage, pageSize,student);

        if( currentPage > page.getPages()){
            page = studentService.getPage((int)page.getPages(), pageSize,student);
        }
        return new R(true, page);
    }
}
