package com.demo.controller;

import com.demo.domain.student;
import com.demo.service.studentService;
import com.demo.utils.ExlUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;


@Controller
public class ExlContlroller {

    private studentService studentService;
    public ExlContlroller(studentService studentService){
        this.studentService=studentService;
    }

    @GetMapping("/indexx")
    public String index() {
        return "indexx";
    }


    @RequestMapping("/uploadExcel")
    @ResponseBody
    public String uploadExcel(@RequestParam("file") MultipartFile file,
                              Map<String, Object> map) {
        String name = file.getOriginalFilename();
        if (name.length() < 6 || !name.substring(name.length() - 5).equals(".xlsx")) {
            return "文件格式错误";
        }
        List<student> list = null;
        int s = 0;
        int d = 0;
        try {
            list = ExlUtils.excelToShopIdList(file.getInputStream());
            if (list == null || list.size() <= 0) {
                return "导入的数据为空";
            }
            //excel的数据保存到数据库

            try {
                for (student excel : list) {
                    if(Strings.isNotEmpty(excel.getStuName())==false||
                            Strings.isNotEmpty(excel.getStuId())==false||
                            Strings.isNotEmpty(excel.getStuMajor())==false||
                            Strings.isNotEmpty(excel.getStuPwd())==false||
                            Strings.isNotEmpty(excel.getStuClassId())==false){
                        d++;
                        continue;
                    }
                    System.out.println(studentService.save(excel));
                    System.out.println(excel.toString());
                    s++;
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
                d++;
                return e.getMessage();
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            return e.getMessage();
        }
        return "保存成功"+s+"个，保存失败"+d+"个";
    }
}
