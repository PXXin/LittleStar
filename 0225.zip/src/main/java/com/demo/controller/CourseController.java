package com.demo.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.demo.domain.class1;
import com.demo.domain.course;
import com.demo.domain.student;
import com.demo.service.courseService;
import com.demo.utils.R;

import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("course")
public class CourseController {
    private final com.demo.service.courseService courseService;

    public CourseController(courseService courseService) {
        this.courseService = courseService;
    }

    @GetMapping("{currentPage}/{pageSize}")
    public R getPage(@PathVariable int currentPage , @PathVariable int pageSize , course course){
        IPage<course> page = courseService.getPage(currentPage, pageSize, course);
        if(currentPage>page.getPages())
            page=courseService.getPage((int)page.getPages(), pageSize,course);
        List<com.demo.domain.course> records = page.getRecords();
        return new R(true,page);
    }

    @PostMapping
    public R save(@RequestBody course course)  {
        course.setcImageLink("");
        boolean flag = courseService.save(course);
        System.out.println("daole");
        return new R(flag, flag ? "添加成功^_^" : "添加失败-_-!");
    }

    @DeleteMapping("{cuuid}")
    public R delete(@PathVariable int cuuid){
        boolean b = courseService.removeById(cuuid);
        return new R(b);
    }
   @PutMapping
    public R update(@RequestBody course course) throws IOException {
        boolean flag = courseService.updateBycuuid(course);
        return new R(flag, flag ? "修改成功^_^" : "修改失败-_-!");
    }
   @GetMapping("{cuuid}")
   public R getById(@PathVariable Integer cuuid){
       return new R(true, courseService.getById(cuuid));
   }
}
