package com.demo.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.demo.domain.class1;
import com.demo.domain.class_course;
import com.demo.domain.student;
import com.demo.service.class_courseService;
import com.demo.utils.R;
//import jdk.swing.interop.SwingInterOpUtils;
import org.apache.ibatis.annotations.Delete;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("ClassCourse")
public class Class_CourseController {
    private final com.demo.service.class_courseService class_courseService;
    private final com.demo.service.classService classService;

    public Class_CourseController(class_courseService class_courseService, com.demo.service.classService classService) {
        this.class_courseService = class_courseService;
        this.classService = classService;
    }

    @GetMapping("{grade}/{cId}/{semester}/{majorr}")
    public R save(@PathVariable String grade,@PathVariable Integer cId,@PathVariable String semester,@PathVariable String majorr){
        int i = class_courseService.saveByGrade(grade, cId, semester, majorr);
        boolean flag=(i>0?true:false);
        System.out.println(i);
        return new R(flag, flag? "添加成功^_^" : "添加失败-_-!");
    }
    @PutMapping
    public R update(@RequestBody class_course cc){
        boolean b = class_courseService.updateById(cc);
        return new R (b,b?"修改成功^_^" : "修改失败-_-!");
    }
    @DeleteMapping(("{uuid}"))
    public R delete(@PathVariable Integer uuid){
        System.out.println("!111111111111");
        return new R(class_courseService.deleteByUuID(uuid));
    }


    @GetMapping("{id}")
    public R gerById(@PathVariable String id){
        //uuid
        class_course cc = class_courseService.getById(id);
        return new R(cc!=null,cc);
    }

    @GetMapping("{currentPage}/{pageSize}")
    public R getPage(@PathVariable int currentPage, @PathVariable int pageSize, class_course class_course){

        IPage<class_course> page = class_courseService.getPage(currentPage, pageSize,class_course);

        if( currentPage > page.getPages()){
            page = class_courseService.getPage((int)page.getPages(), pageSize,class_course);
        }
        return new R(true, page);
    }
    @GetMapping("SDMajor")
    public R getSDMajor(){
        return new R(true, class_courseService.SDMajor());
    }

    @GetMapping("SDSemester")
    public R getSDSemester(String major){
        return new R(true, class_courseService.SDSemester(major));
    }

    @GetMapping("SDGrade")
    public R getSDGrade(String major){
        return new R(true, class_courseService.SDGrade(major));
    }

}
