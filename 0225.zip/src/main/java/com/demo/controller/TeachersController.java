package com.demo.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.demo.utils.R;
import com.demo.domain.teachers;
import com.demo.service.teachersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@RestController
@RequestMapping("/teachers")
public class TeachersController {

    private final teachersService teachersService;

    public TeachersController(teachersService teachersService) {
        this.teachersService = teachersService;
    }

    @GetMapping
    public R getAll(){
        System.out.println("getall being call&&&&&&&&&&&&&&&&&&&&&&&&&");
        return new R(true, teachersService.list());
    }

    @PostMapping
    public R save(@RequestBody teachers teachers) throws IOException {
        System.out.println("save being call");

        boolean flag = teachersService.save(teachers);
        return new R(flag, flag ? "添加成功^_^" : "添加失败-_-!");
    }

    @PutMapping
    public R update(@RequestBody teachers teachers) throws IOException {
        System.out.println("update being call");
        boolean flag = teachersService.modify(teachers);
        return new R(flag, flag ? "修改成功^_^" : "修改失败-_-!");
    }

    @DeleteMapping("{id}")
    public R delete(@PathVariable Integer id){
        return new R(teachersService.delete(id));
    }

    @GetMapping("{id}")
    public R getById(@PathVariable Integer id){
        return new R(true, teachersService.getById(id));
    }

    @GetMapping("{currentPage}/{pageSize}")
    public R getPage(@PathVariable int currentPage,@PathVariable int pageSize,teachers teachers){
        System.out.println("getpage being call&&&&&&&&&&&&&&&&&&&&77==>"+teachers);

        IPage<teachers> page = teachersService.getPage(currentPage, pageSize,teachers);

        if( currentPage > page.getPages()){
            page = teachersService.getPage((int)page.getPages(), pageSize,teachers);
        }
        return new R(true, page);
    }

}

















