package com.demo.utils;

import com.demo.domain.student;
import org.apache.poi.ss.usermodel.*;


import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;


public class ExlUtils {

    public static List<student> excelToShopIdList(InputStream inputStream) {
        List<student> list = new ArrayList<>();
        Workbook workbook = null;
        try {
            workbook = WorkbookFactory.create(inputStream);
            inputStream.close();
            //工作表对象
            Sheet sheet = workbook.getSheetAt(0);
            //总行数
            int rowLength = sheet.getLastRowNum();
            //            System.out.println("总行数有多少行" + rowLength);
            //工作表的列
            Row row = sheet.getRow(0);

            //总列数
            int colLength = row.getLastCellNum();
            //            System.out.println("总列数有多少列" + colLength);
            //得到指定的单元格
            Cell cell = row.getCell(0);
            for (int i = 1; i <= rowLength; i++) {
                student jiFenExcel = new student();
                row = sheet.getRow(i);
                for (int j = 0; j < colLength; j++) {
                    //列： 0姓名	1人员编号	2餐补 3部门
                    cell = row.getCell(j);
                    //                    System.out.print(cell + ",");
                    if (cell != null) {
                        cell.setCellType(Cell.CELL_TYPE_STRING);
                        String data = cell.getStringCellValue();
                        data = data.trim();
                        //                        System.out.print(data);
                        //                        if (StringUtils.isNumeric(data)) {
                        if (j == 0) {
                            jiFenExcel.setStuId(data);
                        } else if (j == 1) {
                            jiFenExcel.setStuPwd(data);
                        } else if (j == 2) {
                            jiFenExcel.setStuName(data);
                        }else if (j == 3) {
                            jiFenExcel.setStuMajor(data);
                        }else if (j == 4) {
                            jiFenExcel.setStuGrade(data);
                        }else if (j == 5) {
                            jiFenExcel.setStuClassId(data);
                        }else if (j == 6) {
                            jiFenExcel.setStuMail(data);
                        }
                    }
                }
                list.add(jiFenExcel);

            }
        } catch (Exception e) {
        }
        return list;
    }
}
