package com.demo;

import com.demo.domain.class_course;
import com.demo.service.class_courseService;
import org.apache.logging.log4j.util.Strings;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;

@SpringBootTest
public class ccTest {

    @Resource
    private class_courseService cc;


    @Test
    public void ByPageTest(){
//        class_course class_course = new class_course();
//        class_course.setMajor("计算");
//        cc.getPage(2,2,class_course);
        String s="";
        System.out.println(s!=null);
        System.out.println(Strings.isNotEmpty(s));
    }
    @Test
    public void ByPageTest1(){
        class_course class_course = new class_course();
        class_course.setSemester("2");
        class_course.setClassId(1608);
        class_course.setcId(1888);
        class_course.setMajor("计算机");
        cc.save(class_course);
    }


}
