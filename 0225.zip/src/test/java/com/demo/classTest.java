package com.demo;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.demo.domain.class1;
import com.demo.domain.class_course;
import com.demo.service.classService;
import com.demo.service.class_courseService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestExecutionListeners;

import javax.annotation.Resource;
import java.util.List;

@SpringBootTest
public class classTest {
    @Resource
    private class_courseService cc;
    @Resource
    private classService classService;
    @Test
    public void Test(){
        System.out.println(classService.getById("1"));
    }
    @Test
    public void ByPageTest(){
        class1 class1 = new class1();
        class1.setClassMajor("计算机");
        IPage<com.demo.domain.class1> page = classService.getPage(2, 2, class1);
        System.out.println(page);
    }



}
