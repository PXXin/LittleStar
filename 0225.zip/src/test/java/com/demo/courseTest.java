package com.demo;

import com.demo.domain.course;
import com.demo.service.courseService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class courseTest {
    @Autowired
    private com.demo.service.courseService courseService;
    @Test
    public void ByPageTest(){
        courseService.getPage(1,2,new course());
    }
}
