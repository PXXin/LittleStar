package com.demo;

import com.demo.domain.student;
import com.demo.service.teachersService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.Map;

@SpringBootTest
public class Studenttest {
    @Autowired
    private com.demo.service.studentService studentService;
    @Autowired
    private com.demo.service.teachersService teachersService;
    @Autowired
    private com.demo.service.classService classService;

    @Test
    void getAllTest(){
        System.out.println(studentService.selectByUuid(111));
    }
    @Test
    void addTest(){
        student student = new student();
        student.setStuClassId("654");
        student.setStuGrade("876");
        student.setStuId("565");
        student.setStuMail("fh");
        student.setStuMajor("计算机");
        student.setStuName("gf");
        student.setStuPwd("gfd");
        studentService.save(student);
        student student1 = new student();
        student1.setStuClassId("4556");
        student1.setStuGrade("654");
        student1.setStuId("45");
        student1.setStuMail("qwtwe");
        student1.setStuMajor("rt");
        student1.setStuName("吴帅r从");
        student1.setStuPwd("wrq");
        studentService.save(student1);
    }

    @Test
    void bypageTest(){

        studentService.getPage(1,2,new student());
    }

    @Test
    void deleteTest(){
        System.out.println(teachersService.delete(22222));
    }

    @Test
    void UpadataClassTest() {

       // System.out.println(maps);
//        List<List<String>> maps = studentService.UpdateClass();
//        System.out.println(maps);
//        for (Map<String, String> map : maps) {
//            String stuClassId = map.get("stuClassId");
//            String stuGrade = map.get("stuGrade");
//           // Integer integer = studentService.countNum(stuClassId, stuGrade);
//
//          //  boolean b = classService.updateByStu(stuClassId, stuGrade, integer);
//        }
    }

}
