package com.demo;

import com.demo.dao.admindao;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;

@SpringBootTest
class DemoApplicationTests {
 @Resource
  private  admindao dao;
      @Test
    void contextLoads() {

          //System.out.println(dao.confirm("1","787877"));
    }

}
