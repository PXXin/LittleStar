package com.demo;

import com.demo.service.teachersService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class teachertest {
    @Autowired
    private com.demo.service.teachersService teachersService;
    @Test
    public void deleteTest(){
        System.out.println(teachersService.delete(22222));
    }
}
